﻿using UnityEngine;
using System.Collections;

public class SoundDef
{
    public const int ID_SOUND_INGAME_BG_MUSIC = 0;
    public const int ID_SOUND_INGAME_BTNCLICK = 1;
}
