﻿namespace Spine {
	public interface IConstraint : IUpdatable {
		int Order { get; }
	}
}